class Raza:
    def __init__(self,nombre,especie,estado):
        self.nombre = nombre
        self.especie = especie
        self.estado = estado