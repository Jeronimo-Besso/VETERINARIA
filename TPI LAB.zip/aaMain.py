from consulta import Consulta
from diagnostico import Diagnosico
from ficha_medica import Ficha_medica
from mascota import Mascota
from persona import Persona
from propietario import Propietario
from raza import Raza
from tratamiento import Tratamiento
from vacuna import Vacuna
from veterinario import Veterinario
mascotasActivas = []
listaTratamientos = []
listaDiagnosticos = []
listaVacunas = []
listaRazas = []
listaVeterinarios = []
listaClientes = []
diagnosticos = []
def nuevaRaza():
    pass
def eliminarRaza():
    pass
def nuevaMascota():
    pass
def eliminarMascota():
    pass
def nuevaPersona():
    pass
def eliminarPersona():
    pass
def nuevoDiagnostico():
    pass
def eliminarDiagnostico():
    pass
def nuevoTratamiento():
    pass
def eliminarTratamiento():
    pass
def nuevaVacuna():
    pass
def eliminarVacuna():
    pass
def encontrarFichaMedica(mascota):
    pass
def crearFicha():
    #codigo para crear archivo nuevo
    pass
def getCantidadMascotas():
    pass
def rankingDiagnosticos():
    pass
def razasPorDiagnostico():
    pass

def menu():
    tarea = int(input("Que quiere hacer: "))

def main():
    menu()
if __name__ == "__main__":
    main()








    