class Consulta:
    def __init__(self,fecha,propietario,veterinario,diagnostico,tratamiento,vacuna):
        self.fecha = fecha
        self.propietario = propietario
        self.veterinario = veterinario
        self.diagnostico = diagnostico
        self.tratamiento = tratamiento
        self.vacuna = vacuna
        