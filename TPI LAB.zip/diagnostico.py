class Diagnosico:
    def __init__(self,descripcion):
        self.diagnostico = diagnostico