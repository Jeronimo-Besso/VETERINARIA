class Persona:
    def __init__(self,nombre,direccion,mail,telefono):
        self.nombre = nombre
        self.direccion = direccion
        self.mail = mail
        self.telefono = telefono