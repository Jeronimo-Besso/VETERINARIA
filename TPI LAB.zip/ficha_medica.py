class Ficha_medica:
    def __init__(Self,descripcion,mascota,consulta,observacion,fecha_alta):
        self.descripcion = descripcion
        self.mascota = mascota
        self.consulta = consulta
        self.observacion = observacion
        self.fecha_alta = fecha_alta