class Tratamiento:
    def __init__(self,algo):
        self.algo = algo