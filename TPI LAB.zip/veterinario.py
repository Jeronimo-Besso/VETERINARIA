class Veterinario:
    def __init__(self,especializacion):
        self.especializacion = especializacion