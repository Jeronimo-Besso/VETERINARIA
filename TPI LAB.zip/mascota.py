class Mascota:
    def __init__(self,nombre,raza,fecha_nacimiento,propietario):
        self.nombre = nombre
        self.raza = raza
        self.fecha_nacimiento = fecha_nacimiento
        self.propietario = propietario