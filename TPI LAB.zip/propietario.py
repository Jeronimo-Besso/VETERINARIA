class Propietario:
    def __init__(self,nro_mascota):
        self.nro_mascota = nro_mascota
